# AWS Production Infra Showcase

This repository demonstrates a **production‑grade AWS infrastructure** including:

- **EKS + ArgoCD** — Kubernetes cluster on Amazon EKS managed via Argo CD for GitOps continuous delivery.
- **S3 + CloudFront Static Hosting** — static website hosted on Amazon S3 and served globally via CloudFront with HTTPS.
- **EventBridge Pipelines & Step Functions** — event‑driven processing using EventBridge rules and Step Functions workflows.
- **Serverless & IaC** — examples built with AWS SAM/CDK for Lambda, plus Terraform for all infrastructure.
- **CloudWatch Dashboards & SLO Alerts** — monitoring dashboards with SLO alerting for availability and latency, integrated with Slack via AWS Chatbot.
- **Secure CI/CD** — GitHub Actions pipelines using OpenID Connect (OIDC) to assume roles in AWS without static credentials.
- **Terraform Backend** — state storage in S3 with locking via DynamoDB to prevent concurrent updates.

This project is provided as a starting point for your own production systems and portfolio. Replace placeholder values with your own AWS account IDs, regions, domain names and Slack channel ARNs before deployment.

## Demo

- 🌓 [Dark Theme (GitHub Pages)](https://vlamay.github.io/aws-production-infra-showcase/)
- ☀️ [Light Theme](https://vlamay.github.io/aws-production-infra-showcase/light.html)
- ☁️ **Live AWS Demo (CloudFront)** — coming soon

## Architecture

This project spans three environments (**dev**, **staging** and **prod**) which share a common Terraform backend stored in S3 with state locking in DynamoDB. EKS clusters run application workloads and are managed by Argo CD. Static assets live in an S3 bucket and are delivered via CloudFront. EventBridge rules trigger Step Functions workflows and Lambda functions. CloudWatch monitors service metrics and raises alarms when SLOs are breached; notifications are sent to Slack via SNS and AWS Chatbot.

A high‑level diagram of the system and a detailed deployment flow are provided in the `/docs` folder (see **architecture.png** and **architecture-cicd.png**).

## Deployment Flow

1. **Commit & Push** — Developers push changes to the `main` branch on GitHub.
2. **CI Pipeline** — GitHub Actions runs `terraform fmt`, `validate` and `plan`, then assumes an AWS role via OIDC and applies changes in the AWS account.
3. **Terraform Backend** — All environments share a central S3 bucket for Terraform state and a DynamoDB table for state locking.
4. **Static Site** — The site in `/docs` is synced to the S3 bucket and CloudFront cache is invalidated.
5. **Kubernetes Deploy** — Argo CD watches the repository and applies updated manifests to the EKS clusters.
6. **Serverless & Pipelines** — EventBridge rules invoke Step Functions and Lambda to handle asynchronous tasks.
7. **Monitoring & Alerts** — CloudWatch dashboards track availability, latency and error rates; alarms publish to SNS, which notifies Slack via AWS Chatbot.
8. **Verification** — Deployed services are available via CloudFront and EKS load balancers.

## Usage

This repo is for demonstration purposes. To provision the infrastructure you need valid AWS credentials and to update variables in the Terraform files. After installing Terraform:

```sh
cd terraform
terraform init
terraform plan
terraform apply
```

For the CI/CD pipeline, add secrets for `AWS_ROLE_TO_ASSUME` and `AWS_REGION` in your GitHub repository settings.

## License

This project is published for educational use under the MIT License.
